import mod1
#from mod1 import add,sub 
#=mod1로부터 add,sub함수를 가져온다는 의미

#from mod1 import* 
#=mod1모듈로부터 함수나 클래스,변수들을 다 가져옴 *(all)

a=mod1.add(10,20)
print(a)
b=mod1.sub(10,5)
print(b)