#함수 선언, 함수 이름:two_times, 매개변수:x
def two_times(x):
    #x의 값에 2를 곱해서 반환
    return x*2

#two_times함수 호출하면서 [1,2,3,4]를 넘김
#map(): 반복하라는 내장함수
#list : map으로 반복한 결과를 리스트로 만들어서 res에 저장
res=list(map(two_times, [1,2,3,4]))
print(res)