#함수 선언, 함수이름:two_times,매개변수(numberList)
def two_times(numberList):
    #리스트변수 선언
    result = []
    #numberList요소의 개수만큼 반복
    for number in numberList:
        #result리스트에 numberList요소값*2한 결과를 추가
        result.append(number*2)
    return result
#two_times함수 호출하면서 [1,2,3,4]리스트 넘김
aa = two_times([1, 2, 3, 4])
print(aa)