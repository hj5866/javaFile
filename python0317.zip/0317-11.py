dic={1:'a',2:'b',3:'c'};
print(dic);
a='k';
dic[a]='d';
print(dic);
#딕셔너리 요소 삭제
del dic[2];
print(dic);
#딕셔너리에서 키(key)를 사용하여 값(value)을 출력
print(dic['k']);