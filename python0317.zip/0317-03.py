head="Python"
tatil=' is fun!'
print(head+tatil)

a="Life is too short"
print(len(a))
print(a[3])
print(a[-1])
print("^"*8)
print(a[0:5])