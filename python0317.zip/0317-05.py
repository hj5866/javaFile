#문자열 개수 세기
a='날이 좋아서,날이 좋지 않아서 모든 날이 좋았다.';
b=len(a);
print(b);

#a변수의 특정 값의 개수 구하기
c=a.count('날'); #날의 개수 구하기
print(c);
d=a.find('모든'); #모의 인덱스 번호 구하기
print(d);
e=a.find('사'); 
print(e);
f=a.index('모든');
print(f);

#문자열 합치기(join)
str=",".join('치킨돈가스우동');
print(str);
str2=",".join(['치킨','돈가스','우동']);
print(str2);

str3="Have a good time"; 
res=str3.upper() #대문자로 바꾸기
print(res)
str4="Have a good time";
res1=str3.lower() #소문자로 바꾸기
print(res1)

#공백 지우기
str5="    화이팅    ";
print(str5);
print(str5.lstrip());
print(str5.rstrip());
print(str5.strip());

#문자열 바꾸기
str6="주말에는 영화를 보러 갈거야";
res5=str6.replace("영화","연극");
print(res5)

#문자열 나누기
str7="일요일에 한강 가서 자전거 탈까?";
res6=str7.split();
print(res6);
str8="일요+일에+한강+가+서+자전거+탈까?";
res7=str8.split('+');
print(res7);