a=[1,2,3,4,5,6,7,8,9,10];
a.append(20); #추가
print(a);
a.sort(); #추가
print(a);
a.reverse();
print(a);
#숫자5에 해당하는 인덱스 번호를 출력
print(a.index(5));
print(a.index(20));
print(a.index(1));
#a리스트의 중간에 데이터 삽입(insert)-0인덱스에 3데이터 삽입
a.insert(0,3);
print(a);
a.insert(7,"만두");
print(a);
#a리스트의 요소 제거
a.remove(1);
print(a);
a.remove(20);#리스트에서 원소 제거
print(a);
a.remove('만두');
print(a);
a.pop(); #리스트의 마지막 원소 제거
print(a);
print(a.pop()); #리스트에서 제거된 원소 반환
print(a);
a.pop(1); #리스트에서 인덱스번호1에 해당하는 원소 반환
print(a);
#리스트에 포함된 요소의 개수 세기
print(a.count(5));
a.append(5);
print(a.count(5));
#리스트 확장
a.extend([100,200]);
print(a);
