#배열(리스트)더하기
a=[1,2,3];
b=[10,20,30];
print(a+b);
print(a*3);
#print(a*b); 에러
#print(a-b);

print( b[10])