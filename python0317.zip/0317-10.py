#튜플
t1=();
t2=(1,);
t3=(1,2,3);
t4=1,2,3;
t5=('돈가스','우동','소바');
t6=('a','b',('ab','cd'));
print(t1);
print(t2);
print(t3);
print(t4);
print(t5);
print(t6);
#t3.remove(2); 튜플은 요소를 추가,제거할수없다.
#t3.append(4);
print(t3.index(1)); #t3튜플에서 데이터2의 인덱스 번호는 1 출력
print(t5.index("소바"))
print(t3[1]); #t3튜플서 1번방(인덱스가1)의 값 출력
print(t5[0])
#튜플 슬라이싱
t7=('a','b','c','d','e','f');
print(t7[2:]); #인덱스번호 2번~끝까지
print(t7[3:]); #인덱스번호 3번~끝까지
print(t7[:4]); #처음부터 인덱스 번호 (4-1)까지
print(t7[:3]);
print(t7[:2]);
print(t7[2:4]); #인덱스번호 2부터 ~인덱스번호(4-1)까지
print(t3+t5);
print(t5*3); #t5튜플을 3번 반복