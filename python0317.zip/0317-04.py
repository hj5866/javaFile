str="나는 사과를 %d 개 먹었다." % 3
print(str)
str2="나는 점심에 %s를 마셨다." % "우유"
print(str2)
num=10
day="3일"
str3="나는 %d개를 사과를 먹었다 %s 동안 먹었다." % (num,day)
print(str3)
str4="{0:>10}".format("안녕") #오른쪽 정렬
print(str4)
str5="{0:<10}".format("안녕") #왼쪽 정렬
print(str5)
str6="{0:^10}".format("안녕") #가운데 정렬
print(str6)
num=3.42134234
print(num)
print(f'{num:0.2f}') #소수점 2자리 까지만 출력, 앞의 f(format), 뒤의 f(float)
num2=52.95643
print(num2)
print(f'{num2:10.3f}') #10자리 확보, 소수점 3자리까지 출력