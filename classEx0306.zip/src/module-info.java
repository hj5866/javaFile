/**
 * 
 */
/**
 * @author vip
 *
 */
module classEx0306 {
}