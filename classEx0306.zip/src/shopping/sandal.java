package shopping;

public class sandal {

}
