package shopping;

public class Person {
	String name;
	int money;
	
	Person(String name, int money){
		this.name=name;
		this.money=money;
	}
	
	public void buySandal(lotte sandal, int money) {
		String msg=sandal.brew(300000);
		this.money -= money;
		System.out.println(name+"���� "+money+"���� "+msg);
	}
	public void buyTshirt(lotte shirt, int money) {
		String msg=shirt.brew(240000);
		this.money -= money;
		System.out.println(name+"���� "+money+"���� "+msg);

}
}
