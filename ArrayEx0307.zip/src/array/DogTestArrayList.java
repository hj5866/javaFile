package array; 

import java.util.ArrayList;

public class DogTestArrayList {
	String Dogname;
	String Dogtype;
	ArrayList<Dog> dogList=new ArrayList<Dog>();
	
	
	public void addDog(String name, String type) {
		Dog dog = new Dog();
		dog.setName(name);
		dog.setType(type);
		dogList.add(dog);
	}
    
	Dog doglee = new Dog();
	doglee.addDog()
	
	
	
	
	
	
	
}
