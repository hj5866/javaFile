/**
 * 
 */
/**
 * @author vip
 *
 */
module ArrayEx0307 {
}