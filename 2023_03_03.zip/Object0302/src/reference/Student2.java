package reference;

public class Student2 {

}
