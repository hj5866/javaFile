/**
 * 
 */
/**
 * @author vip
 *
 */
module Object0302 {
}