/**
 * 
 */
/**
 * @author vip
 *
 */
module classEx0303 {
}