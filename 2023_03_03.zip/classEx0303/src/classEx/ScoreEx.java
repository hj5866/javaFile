package classEx;

public class ScoreEx {
	String nomaltype,freetype,adult,teenager,date;
	int discount,day,age;
	double price;
	
	public String getNomaltype() {
		return nomaltype;
	}
	public String getFreetype() {
		return freetype;
	}
	public String getAdult() {
		return adult;
	}
	public String getTeenager() {
		return teenager;
	}
	public int getAge() {
		
		if(age>=19) {
			System.out.println("� �Դϴ�.");
		}else {
			System.out.println("û�ҳ� �Դϴ�.");
		}
		return age;
	}
	public void getDay() {
		
		if(day==10) {
			System.out.println("10�Ͽ� ���� �ϼ̽��ϴ�.");
		}else {
			System.out.println("1������ ���� �ϼ̽��ϴ�.");
		}
		//return day;
	}
    public int getDiscount() {
   
	     if(age>=19 && day==10) {
	    	 discount=45;
	    	 
	     }else if(age>=19 && day!=10) {
	         discount=50;
	         
	     }else if(age<19) {
	    	 discount=60;
	     }
	     return discount;
	    
    }
	public double getPrice() {
		price=59800;
	    double finalprice=0;
	    
	  
		if(discount==45) {
			finalprice=price-(price*0.45);
			
		}else if(discount==50) {
			finalprice=price-(price*0.5);
			
		}else if(discount==60) {
			finalprice=price-(price*0.6);
		}
		return finalprice;
	}
		

	public static void main(String[] args) {
		
		ScoreEx ticket=new ScoreEx();
		ScoreEx ticket2=new ScoreEx();
        
		ticket.age=23;
	    ticket.day=10;
		
		ticket2.age=17;
		ticket2.day=30;
		
	
		ticket.getAge();
		ticket.getDay();	
		System.out.println("�������� "+ticket.getDiscount()+"% �Դϴ�.");
		System.out.println("���������� "+(int)+ticket.getPrice()+"�� �Դϴ�.");
		
		System.out.println();
		
	    ticket2.getAge();
	    ticket2.getDay();	
		System.out.println("�������� "+ticket2.getDiscount()+"% �Դϴ�.");
		System.out.println("���������� "+(int)+ticket2.getPrice()+"�� �Դϴ�.");
		
		
		
	}

}
