package Home;

public class Homework04 {

	public static void main(String[] args) {
          
        int imsi=0;
		
		for(int i=1; i<=4; i++) {
			imsi=(i-1)*5;
			
		 for(int j=imsi+1; j<=imsi+5; j++) {
			 System.out.print(j+" ");
				
					
				}
		 System.out.println();
			
				
				
				
			}
        

	}

}
