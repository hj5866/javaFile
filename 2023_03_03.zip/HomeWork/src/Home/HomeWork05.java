package Home;

public class HomeWork05 {

	public static void main(String[] args) {
		for(int i=10; i<=50; i+=10) {
			for(int j=1; j<=5; j++) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
		

	}

}
