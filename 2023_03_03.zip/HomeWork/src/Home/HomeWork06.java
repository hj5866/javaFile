package Home;

public class HomeWork06 {

	public static void main(String[] args) {
		int num=0;
		
		for(int i=1; i<5; i++) {         //�� ȸ��
			for(int j=1; j<=5; j++) { //�� ȸ��
				
				
			System.out.print(j);
				
		}
		System.out.println();

	}

}
}