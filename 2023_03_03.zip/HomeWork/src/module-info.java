/**
 * 
 */
/**
 * @author vip
 *
 */
module HomeWork {
}