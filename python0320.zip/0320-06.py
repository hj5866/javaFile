#정수형 변수 선언 및 초기화
add=0;
#i변수의 값이 1부터 시작해서 11보다 작을 때 까지
for i in range(1,11):
    print(i)
    add=add+i

print("1~10까지의 누적합은 %d 입니다." %add)