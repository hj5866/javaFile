#리스트 선언
marks=[90,40,50,60,70];
#정수형 변수 선언
number=0;
for mark in marks:
    number=number+1
    if mark >= 60:
        print("%d번 학생은 합격입니다."%number)
    else:
        print("%d번 학생은 불합격입니다."%number)