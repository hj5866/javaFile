#함수 선언: def,  함수명: add,  매개변수: a,b
def add(a,b):
    return a+b

def sub(a,b):
    return a-b

def mul(a,b):
    return a*b

def div(a,b):
    return a/b

#키보드로 숫자를 입력받아서 변수에 저장
#input으로 입력받은 요소는 문자열로 인식
x=input("숫자를 입력하세요:")
y=input("숫자를 입력하세요:")

#문자형 요소를 정수형으로 형변환
x=int(x)
y=int(y)

#함수 호출, x값은 add함수의 a변수로 받고, y값은 b변수로 받음
c=add(x,y)
print("%d와 %d를 더한 값은 %d입니다." %(x,y,c))
h=sub(x,y)
print("%d와 %d를 뺀 값은 %d입니다." %(x,y,h))
i=mul(x,y)
print("%d와 %d를 곱한 값은 %d입니다." %(x,y,i))
j=sub(x,y)
print("%d와 %d를 나눈 값은 %.1f입니다." %(x,y,j))
#실수형으로 바꾸고싶으면 %d를 %.1f 로 바꾸면 됌!
#시험문제 나옴!!#