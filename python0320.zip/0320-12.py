#함수선언, 함수명:add_mnl, 매개변수:choice, *args(길이가 정해져 있지 않음)
def add_mul(choice, *args): # *는 어레이 리스트처럼 유연하게 사용가능 
     #만약 choice변수값이 "add"라면
     if choice == "add": 
         #result변수 선언 및 초기화
         result = 0
         # *args만큼 반복 
         for i in args:
             #result변수에 i값을 누적으로 더함 
             result = result + i
     #만약 choice변수값이 "mul"이라면 
     elif choice == "mul":
         #result변수 선언 및 초기화 
         result = 1
         # *args만큼 반복 
         for i in args:
             #result 변수에 i값을 누적으로 곱함 
             result = result * i
    #최종 연산된 result변수의 값을 호출한 곳으로 반환한다 
     return result 
#함수호출
res=add_mul("add",10,20,30,40,50,60,70,80,90,100)
print(res)