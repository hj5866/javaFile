#marks리스트 선언 및 요소 저장
marks=[90,25,67,45,80];
#marks 개수만큼 반복, mark변수가 리스트의 요소를 가리키는 변수
#len[marks]:marks리스트의 요소의 총 개수(길이) 구하는 함수
for mark in range(len(marks)):
    if marks[mark] < 60:
        continue
    print("%d번 학생은 합격 입니다."%(mark+1)) #+1을 해야 1번학생부터 세니까