pocket = ['paper','cellphone']
card=['kb','woori','sh']
#만약 pocket리스트 요소에 money가 있으면 True
if 'money' in pocket:
    print("택시를 타고 가라")
else:
    if 'nh'in card:
        print("택시를 타고 가라")
    else:
        print("따릉이 타고 가라")
    