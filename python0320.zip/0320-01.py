s1=set([1,2,3]); #set자료형
l1=list(s1); #set자료형을 리스트로 변환
print(l1);
print(l1[0]);
s2=set([10,20,30,40,50]);
s3=set([10,20,300,400,500]);
#교집합(intersection)
print(s2 & s3);
print(s2.intersection(s3));
#합집합(union)
print(s2 | s3);
print(s2.union(s3));
#차집합(difference)
print(s2 - s3);
print(s2.difference(s3));
s2.add(1000);
print(s2);
s3.update([6,9])
print(s3);
s3.remove(500);
print(s3);