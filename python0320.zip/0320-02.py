a=[1,2,4,5];
#a변수의 값이 true이면 print문 실행, false이면 while문 빠져나감
while a:
    print(a.pop());
    print(a); #리스트에 값이 다 빠져나가면(pop때문에)false라서 while문 끝남!
if a:
    print("참");
else:
    print("거짓");
