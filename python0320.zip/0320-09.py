a=[1,2,3,4]
res = [num * 3 for num in a]
print(res)
#a의 요소만큼 반복하면서 요소에3을 곱한다.(짝수라면.)
res2=[num*3 for num in a if num % 2 ==0]
print(res2)