class FourCal:
    n=0;
    m=0;
    #생성자(initializer)
    def __init__(self,s,r):
        self.s=s #멤버변수 초기화
        self.r=r
       
    #계산작업하는 일반 메서드
    def calc(self):
        res2=self.s*self.r
        return res2


#클래스 FourCal을 사용하여 a객체를 생성
a=FourCal(10,20) #인스턴스
print(a.calc())