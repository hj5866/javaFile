#변수 i값이 2부터 9까지 반복
for i in range(2,10):
    #변수 j값이 1부터 9까지 반복
    for j in range(1,10):
        #end="":그 줄에 계속해서 출력
        print(i*j,end=" ")
    #줄바꿈
    print(' ')