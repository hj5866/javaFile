#함수명=lambda 매개변수1, 매개변수2, ...:
#매개변수를 이용한 표현식(lambda)
add=lambda a, b:a+b 

def add(a,b):
    return a+b
res = add(10,20)
print(res)