package test;

import java.util.Scanner;

public class Test_03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("�̸�:");
		String name = sc.nextLine();
		
		System.out.println("����:");
		int age = sc.nextInt();
		
		System.out.println("����:");
		String job = sc.nextLine();
		
		System.out.println("�ּ�:");
		String addr = sc.nextLine();
		
		System.out.println("����:");
		char gender = sc.next().charAt(0);
		
		
		System.out.println("�̸�:"+name);
		System.out.println("����:"+age+"��");
		System.out.println("����:"+job);
		System.out.println("�ּ�:"+addr);
		System.out.println("����:"+gender);

	}

}
