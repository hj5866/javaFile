package test;

import java.util.Scanner;

public class Test_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String[] names = new String[5];
		int[] age = new int[5];
		
		int n= names.length;
		
		for(int i=0; i<n; i++); {
			
		System.out.println("�̸�:");
		int i = 0;
		names[i] = sc.nextLine();
		System.out.println("����:");
		age[i] = sc.nextInt();
		}
		
		
		for(int i=0; i<n; i++) {
		System.out.println("�̸�:"+names[i]+","+" ����:"+age[i]+"��");

	}

}
}

