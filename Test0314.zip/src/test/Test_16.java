package test;

public class Test_16 {

	public static void main(String[] args) {
		
        int arr[] = new int[10];
        int imsi=0;
        int key=0;
        int max=0;
        int min=999;
		
		System.out.print("�迭�� ��:");
		
		for(int i=0; i<arr.length; i++) {
			int random = (int)(Math.random()*100);
			arr[i]=random;
			
			System.out.print(arr[i]+",");
			
			if(arr[i] > max) {
				max=arr[i];
	        if(arr[i] < min) {
					min=arr[i];
	        }
	}
		}
	for(int i=1; i<arr.length; i++) {
				key=arr[i]; 
				for(int j=i-1; j>=0; j--) {
					if(key < arr[j]) {						
			         	imsi=arr[j+1];
						arr[j+1]=arr[j];
						arr[j]=imsi;	
					}
				} 
	}
	            System.out.println();
			    System.out.print("���ĵ� �迭�� ��:");
				for(int k=0; k < arr.length; k++) {
					System.out.print(arr[k]+",");
				}
	}
	
    


	

	}



