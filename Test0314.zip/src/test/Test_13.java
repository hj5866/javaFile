package test;

public class Test_13 {

	public static void main(String[] args) {
		
		int arr[] = new int[10];
		
		System.out.print("�迭�� ��:");
		
		for(int i=0; i<arr.length; i++) {
			int random = (int)(Math.random()*122-65)+65;
			arr[i]=random;
			
			System.out.print(arr[i]+",");


	}
     
}
}
