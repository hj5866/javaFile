package test;

import java.util.Scanner;

public class Test_09 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String arr[] = new String[6];
		int a=arr.length;
		
		for(int i=0; i<a; i++);{
		System.out.println("���ϸ�:");
		String fruit = sc.nextLine();

	}
        
}
}
