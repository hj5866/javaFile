package test;

public class Test05_test {
	

	public static void main(String[] args) {

	Test05 ice = new Test05();
	
	ice.setName("������");
	ice.setType("F");
	ice.setCount(5);
	
	System.out.println(ice.showInfo());

	

}
}
