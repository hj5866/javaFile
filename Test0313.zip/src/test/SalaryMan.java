package test;

public class SalaryMan {
	
 private String name,addr,dept;
 private int num;
 
 public String getName() {
	 return name;
 }
 public void setName(String name) {
	 this.name=name;
 }
 public String getAddr() {
	 return addr;
 }
 public void setAddr(String addr) {
	 this.addr=addr;
 }
 public String getDept() {
	 return dept;
 }
 public void setDept(String dept) {
	 this.dept=dept;
 }
 public int getNum() {
	 return num;
 }
 public void setNum(int num) {
	 this.num=num;
 }
 
	 
 }
 
 

