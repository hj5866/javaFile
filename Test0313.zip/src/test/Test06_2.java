package test;

public class Test06_2 {
	public static void main(String[] args) {

	Test06_1 U = new Test06_1();
	
	U.setName("���缮");
	U.setKor(70);
	U.setEg(80);
	U.setMath(60);
	
	U.Info();
	
	System.out.println();
	
	Test06_1 E = new Test06_1();
	
	E.setName("�̹���");
	E.setKor(90);
	E.setEg(75);
	E.setMath(70);
	
	E.Info();
	
	
}
}
