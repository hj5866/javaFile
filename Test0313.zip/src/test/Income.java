package test;

public class Income extends SalaryMan{
	
 private String position;
 private int salary;
 double price;
 
 public String getPosition() {
	 return position;
 }
 public void setPosition(String position) {
	 this.position=position;
 }
 public int getSalary() {
	 return salary;
 }
 public void setSalary(int salary) {
	 this.salary=salary;
 }
 public double getPrice() {
	 return getSalary()/12.0;
 }
 public void setPrice(double price) {
	 this.price=price;
 }
 public void info() {
	 System.out.println("���� ��ȣ:"+getNum());
	 System.out.println("���� �̸�:"+getName());
	 System.out.println("���� �ּ�:"+getAddr());
	 System.out.println("�Ҽ� �μ�:"+getDept());
	 System.out.println("���� ����:"+getPosition());
	 System.out.println("����:"+getSalary());
	 System.out.printf(getName()+"�� ���޿�:"+"%.0f",getPrice());
 }
}
