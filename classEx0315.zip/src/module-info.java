/**
 * 
 */
/**
 * @author vip
 *
 */
module classEx0315 {
}