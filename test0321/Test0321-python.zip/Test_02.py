a = (10, 20, 30, 40, 50)
b = ('apple','banana','orange','grape','mango')
print(a[3:])

print(a+b)

print(a*3)

c=a+b
print(len(c))

print(b[2])