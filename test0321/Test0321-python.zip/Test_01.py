a = ['자바','파이썬','C++','PHP','데이터베이스','자바스크립트','html','css']
b = [100, 200, 300, 400, 500]
print(a[0:5])

print(a+b)

a.append("리액트")
print(a)

a.remove("C++")
print(a)

b.pop()
print(b)
print(b.pop())
