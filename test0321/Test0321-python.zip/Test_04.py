x=input("등급을 입력하세요:")
b=5000

if x =='A' :
    b = b-(b*0.2)
    print("등급:"+x)
    print("할인된 가격:%d"%b+"원")
    
elif x == 'B': 
    b= b-(b*0.1)
    print("등급:"+x)
    print("할인된 가격:%d"%b+"원")

elif x =='C':
    b= b-(b*0.05)
    print("등급:"+x)
    print("할인된 가격:%d"%b+"원")

elif x =='D':
    print("등급:"+x)
    print("할인이 없습니다")
