total = 0
count = 0
for i in range(1,101): 
  if i%2 == 0:  
    total += i 
    count = count+1 
print("1~100 까지의 정수 중 짝수의 개수: %d" %count)
print("1~100 까지의 정수 중 짝수의 합계 : %d" %total)