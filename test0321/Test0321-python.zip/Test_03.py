a = { "이름":"홍길동","성별":"남","나이": 30,"주소":"인천"}

b="취미"
a[b]="영화감상"
print(a)

del a["성별"]
print(a)

print(a["주소"])

print(a.keys())

print(a.values())
