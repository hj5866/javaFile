package test;

public class Student {
	
	private String name,id,adr;
    private int k,e,m;
    private int sum;
	private double avg;
	private char grade;
    
	public int getK() {
		return k;
	}
	public void setK(int k) {
		this.k = k;
	}
	public int getE() {
		return e;
	}
	public void setE(int e) {
		this.e = e;
	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m = m;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public char getGrade() {
		if(avg>=90) {
			grade='A';
		}else if(avg>=80 && avg<90) {
			grade='B';
		}else if(avg>=70 && avg<80) {
			grade='C';
		}else if(avg>=60 && avg<70) {
			grade='D';
		}else {
			grade='F';
		}
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	public int getSum() {
		sum=getK()+getM()+getE();
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public double getAvg() {
		avg=sum/3;
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public void Info() {
		System.out.println("�л� �̸�:"+getName());
		System.out.println("���� ����:"+getK());
		System.out.println("���� ����:"+getE());
		System.out.println("���� ����:"+getM());
		System.out.println("����:"+getSum());
		System.out.println("���:"+getAvg());
		System.out.println("����:"+getGrade());
	}

}

