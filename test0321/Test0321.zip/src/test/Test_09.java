package test;

public class Test_09 {

		String name,place,grade;
		int age=0;
		int pay=0;
		String str;
		
 public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	public String getPlace() {
			return place;
		}
	public void setPlace(String place) {
			this.place = place;
		}
	public int getAge() {
		if(age>=14) {
			str="(��������)";
		}else{
			str="(�����Ұ�)";
			pay=0;
			place="����";
		}
			return age;
		}
public void setAge(int age) {
			this.age = age;
		}
	public int getPay() {
		if(grade=="VIP��") {
			pay=160000;
		}else if(grade=="R��") {
			pay=140000;
		}else if(grade=="S��") {
			pay=110000;
		}else if(grade=="A��") {
			pay=80000;
		}else {
			pay=0;
		}
			return pay;
		}
	public void setPay(int pay) {
			this.pay = pay;
		}
	public String getStr() {
			return str;
		}
public void setStr(String str) {
			this.str = str;
		}

public String getGrade() {
	
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public static void main(String[] args) {
	    	
	    	Test_09 kim = new Test_09();
	    	
	    	kim.setName("��ǹ�");
	    	kim.setAge(29);
	    	kim.setPlace("���Ե�������");
	    	kim.setGrade("S��");
	    	
	    	System.out.println("�̸�:"+kim.getName());
	    	System.out.println("����:"+kim.getAge()+"��"+kim.getStr());
	    	System.out.println("����:"+kim.getGrade()+"-"+kim.getPay()+"��");
	    	System.out.println("���:"+kim.getPlace());
	    	
	    	System.out.println();
	    	
            Test_09 park = new Test_09();
	    	
	    	park.setName("�����");
	    	park.setAge(13);
	    	park.setPlace("");
	    	park.setGrade("");
	    	
	    	System.out.println("�̸�:"+park.getName());
	    	System.out.println("����:"+park.getAge()+"��"+park.getStr());
	    	System.out.println("����:"+park.getGrade()+park.getPay()+"��");
	    	System.out.println("���:"+park.getPlace());
	}

}
