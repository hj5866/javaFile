package test;

public class Test_01 {
	public static void main(String[] args) {
		
		Student H = new Student();
		
		H.setName("ȫ�浿");
		
		System.out.println(H.getName());
		
}
}
