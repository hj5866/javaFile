package test;

public class Test_10 extends Student{
	public static void main(String[] args) {
	
	Student u = new Student();
	
	u.setName("���缮");
	u.setK(70);
	u.setE(80);
	u.setM(65);
	
	u.Info();
	
	System.out.println("=============");
	
Student i = new Student();
	
	i.setName("�̹���");
	i.setK(70);
	i.setE(60);
	i.setM(65);

	i.Info();
	
	}
}


