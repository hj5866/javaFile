package inheritance;

public class PensionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
