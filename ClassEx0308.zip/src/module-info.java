/**
 * 
 */
/**
 * @author vip
 *
 */
module ClassEx0308 {
}